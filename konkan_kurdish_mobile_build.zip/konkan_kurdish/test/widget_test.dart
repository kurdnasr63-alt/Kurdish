import 'package:flutter_test/flutter_test.dart';
import 'package:konkan_kurdish/game/konkan_engine.dart';

void main() {
  test('starts a 106-tile round and deals 15/14/14/14', () {
    final game = KonKanEngine()..startRound();
    expect(game.human.rack.length, 15);
    expect(game.players[1].rack.length, 14);
    expect(game.players[2].rack.length, 14);
    expect(game.players[3].rack.length, 14);
    expect(game.stock.length, 49);
  });

  test('recognizes a same-colour run', () {
    final game = KonKanEngine();
    expect(game.isValidMeld(const [
      Tile(TileColor.blue, 4),
      Tile(TileColor.blue, 5),
      Tile(TileColor.blue, 6),
    ]), isTrue);
  });
}
