import 'package:flutter/material.dart';
import 'game/konkan_engine.dart';

void main() => runApp(const KonKanApp());

const navy = Color(0xFF071B49);
const gold = Color(0xFFFFC928);

class KonKanApp extends StatelessWidget {
  const KonKanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'کۆنگان کوردی',
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: navy), scaffoldBackgroundColor: const Color(0xFFF3F6FC)),
        builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const HomePage(),
      );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF071B49), Color(0xFF123D83)])),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(width: 154, height: 154, decoration: BoxDecoration(shape: BoxShape.circle, color: navy, border: Border.all(color: gold, width: 5), boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 24)]), child: const Icon(Icons.extension_rounded, color: gold, size: 88)),
                  const SizedBox(height: 18),
                  const Text('یاری کۆنگان', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900)),
                  const Text('کوردی سۆرانی', style: TextStyle(color: gold, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 34),
                  _HomeButton(icon: Icons.smart_toy, label: 'یاری ئۆفلاین · دژی AI', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GamePage()))),
                  const SizedBox(height: 12),
                  _HomeButton(icon: Icons.public, label: 'یاری ئۆنلاین', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OnlinePage()))),
                  const SizedBox(height: 12),
                  _HomeButton(icon: Icons.menu_book, label: 'فێربوونی یاساکانی یاری', onTap: () => showDialog(context: context, builder: (_) => const RulesDialog())),
                  const SizedBox(height: 28),
                  const Text('وەشانی سەرەتایی 0.1', style: TextStyle(color: Colors.white70)),
                ]),
              ),
            ),
          ),
        ),
      );
}

class _HomeButton extends StatelessWidget {
  const _HomeButton({required this.icon, required this.label, required this.onTap});
  final IconData icon; final String label; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => SizedBox(width: 320, height: 54, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: navy, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: onTap, icon: Icon(icon), label: Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))));
}

class GamePage extends StatefulWidget { const GamePage({super.key}); @override State<GamePage> createState() => _GamePageState(); }
class _GamePageState extends State<GamePage> {
  final engine = KonKanEngine();
  final Set<int> selected = {};
  @override void initState() { super.initState(); engine.startRound(); }
  Color tileColor(TileColor c) => switch (c) { TileColor.red => Colors.red.shade700, TileColor.black => Colors.blueGrey.shade900, TileColor.blue => Colors.blue.shade700, TileColor.yellow => Colors.amber.shade700, TileColor.antique => Colors.purple.shade700 };
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مێزی کۆنگان'), backgroundColor: navy, foregroundColor: Colors.white, actions: [IconButton(onPressed: () => setState(() { engine.startRound(); selected.clear(); }), icon: const Icon(Icons.refresh), tooltip: 'دەوری نوێ')]),
    body: Column(children: [
      Container(width: double.infinity, color: const Color(0xFF123D83), padding: const EdgeInsets.all(12), child: Column(children: [const Text('تیمی تۆ  ·  دژی تیمی ڕکابەر', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [for (var i = 1; i < 4; i++) _playerChip(engine.players[i])]) ])),
      Expanded(child: Container(color: const Color(0xFF176344), padding: const EdgeInsets.all(12), child: Column(children: [
        const Text('مێزی یاری', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [ _pile('کۆمەڵەی وەرگرتن', engine.stock.length.toString(), Icons.layers), const SizedBox(width: 22), _pile('پارچەی فڕێدراو', engine.topDiscard == null ? '—' : engine.topDiscard!.shortName, Icons.delete_outline) ]),
        const Spacer(),
        Container(width: double.infinity, padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(12)), child: Text(engine.status, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white))),
        const SizedBox(height: 8),
      ]))),
      Container(color: navy, padding: const EdgeInsets.fromLTRB(8, 10, 8, 14), child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('پارچەکانی تۆ', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), Text('${engine.human.rack.length} پارچە', style: const TextStyle(color: Colors.white70))]),
        const SizedBox(height: 8),
        SizedBox(height: 84, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: engine.human.rack.length, separatorBuilder: (_, __) => const SizedBox(width: 5), itemBuilder: (context, i) { final t = engine.human.rack[i]; final active = selected.contains(i); return GestureDetector(onTap: () => setState(() { if (active) { selected.remove(i); } else { selected.add(i); } }), child: AnimatedContainer(duration: const Duration(milliseconds: 120), width: 48, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: active ? gold : tileColor(t.color), width: active ? 4 : 2), boxShadow: active ? const [BoxShadow(color: gold, blurRadius: 8)] : []), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(t.shortName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: tileColor(t.color))), const SizedBox(height: 3), Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: tileColor(t.color)))]))); })),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [FilledButton(onPressed: engine.roundOver ? null : () => setState(() { engine.drawStock(); selected.clear(); }), child: const Text('وەرگرتن لە کۆمەڵە')), FilledButton(onPressed: engine.roundOver ? null : () => setState(() { engine.takeDiscard(); selected.clear(); }), child: const Text('وەرگرتنی فڕێدراو')), FilledButton(onPressed: selected.length != 1 || engine.roundOver ? null : () => setState(() { engine.discardTile(selected.first); selected.clear(); }), child: const Text('فڕێدانی پارچە')), FilledButton(onPressed: selected.isEmpty || engine.roundOver || engine.human.opened ? null : () => setState(() { engine.openWithSelected(selected.toList()); selected.clear(); }), child: const Text('کردنەوە (٨١)')), OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: Colors.white), onPressed: () => showDialog(context: context, builder: (_) => const RulesDialog()), child: const Text('یاساکان'))]),
      ])),
    ]),
  );
  Widget _playerChip(PlayerState p) => Column(children: [CircleAvatar(backgroundColor: p.isHuman ? gold : Colors.white24, child: Icon(p.isHuman ? Icons.person : Icons.smart_toy, color: navy)), const SizedBox(height: 4), Text('${p.name} · ${p.rack.length}', style: const TextStyle(color: Colors.white, fontSize: 12))]);
  Widget _pile(String label, String value, IconData icon) => Column(children: [Container(width: 70, height: 82, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(9), border: Border.all(color: gold, width: 2)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: navy), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, color: navy))])), const SizedBox(height: 5), Text(label, style: const TextStyle(color: Colors.white, fontSize: 11))]);
}

class OnlinePage extends StatelessWidget { const OnlinePage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('یاری ئۆنلاین')), body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.cloud_queue, size: 72, color: navy), const SizedBox(height: 16), const Text('قۆناغی ئۆنلاین', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('ڕووکاری ژووری تایبەت و بەشی ئۆنلاین لەم وەشانەدا دیزاین کراوە؛ بۆ یاری ڕاستەقینە پێویستە سێرڤەر و سیستەمی هەژمار زیاد بکرێت.', textAlign: TextAlign.center), const SizedBox(height: 18), FilledButton(onPressed: () => Navigator.pop(context), child: const Text('گەڕانەوە'))])))); }

class RulesDialog extends StatelessWidget { const RulesDialog({super.key}); @override Widget build(BuildContext context) => AlertDialog(title: const Text('پوختەی یاساکانی کۆنگان'), content: const SingleChildScrollView(child: Text('• ٤ یاریزان بە دوو تیمی دوو کەسی.
• ١٠٦ پارچە: ٤ ڕەنگ، ژمارەی ١ تا ١٣، دوو لە هەر ژمارەیەک و دوو پارچەی ئەنتیک.
• یاریزانەکان گرووپ (هەمان ژمارە بە ڕەنگی جیاواز) یان ڕیز (هەمان ڕەنگ بە ژمارەی بەردەوام) دروست دەکەن.
• کردنەوەی ئاسایی لە وەشانی هەولێر ٨١ خاڵە.
• هەر نۆرەیەک پارچە وەربگرە و یەک پارچە فڕێ بدە.
• یاساکانی Joker و KonKan و خاڵدانانی تەواو لە قۆناغی داهاتوودا زیاد دەکرێن.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشە'))]); }
}
