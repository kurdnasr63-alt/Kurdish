import 'dart:math';

enum TileColor { red, black, blue, yellow, antique }

class Tile {
  const Tile(this.color, this.number, {this.copy = 0});
  final TileColor color;
  final int number;
  final int copy;

  bool get isAntique => color == TileColor.antique;
  int get points => number == 1 || number >= 10 ? 10 : number;
  String get shortName => isAntique ? 'A' : '$number';

  @override
  String toString() => '${color.name}-$number-$copy';
}

class PlayerState {
  PlayerState({required this.name, required this.isHuman, required this.team});
  final String name;
  final bool isHuman;
  final int team;
  List<Tile> rack = [];
  bool opened = false;
  int openingPoints = 0;
}

class KonKanEngine {
  KonKanEngine({Random? random}) : _random = random ?? Random();
  final Random _random;
  late List<Tile> stock;
  final List<Tile> discard = [];
  late List<PlayerState> players;
  int currentPlayer = 0;
  Tile? cap;
  Tile? jokerTile;
  int reshuffles = 0;
  bool roundOver = false;
  String status = 'یاری دەستی پێکرد';

  void startRound() {
    stock = [];
    discard.clear();
    reshuffles = 0;
    roundOver = false;
    players = [
      PlayerState(name: 'تۆ', isHuman: true, team: 0),
      PlayerState(name: 'یار', isHuman: false, team: 1),
      PlayerState(name: 'هاوڕێ', isHuman: false, team: 0),
      PlayerState(name: 'ڕکابەر', isHuman: false, team: 1),
    ];
    for (final color in [TileColor.red, TileColor.black, TileColor.blue, TileColor.yellow]) {
      for (var n = 1; n <= 13; n++) {
        stock.add(Tile(color, n, copy: 0));
        stock.add(Tile(color, n, copy: 1));
      }
    }
    stock.add(const Tile(TileColor.antique, 0));
    stock.add(const Tile(TileColor.antique, 1));
    stock.shuffle(_random);
    for (var p = 0; p < 4; p++) {
      final count = p == 0 ? 15 : 14;
      players[p].rack = List.generate(count, (_) => stock.removeLast());
    }
    cap = stock.removeLast();
    if (cap!.isAntique) {
      cap = stock.removeLast();
    }
    final jokerNumber = cap!.number == 1 ? 13 : cap!.number - 1;
    jokerTile = Tile(cap!.color, jokerNumber);
    currentPlayer = 0;
    status = 'کاپ: ${tileLabel(cap!)} · جوکەر: ${tileLabel(jokerTile!)}';
  }

  PlayerState get human => players[0];
  Tile? get topDiscard => discard.isEmpty ? null : discard.last;

  bool drawStock() {
    if (roundOver || currentPlayer != 0 || stock.isEmpty) return false;
    human.rack.add(stock.removeLast());
    status = 'پارچەیەکت وەرگرت؛ ئێستا یەک پارچە فڕێ بدە';
    return true;
  }

  bool takeDiscard() {
    if (roundOver || currentPlayer != 0 || discard.isEmpty) return false;
    final tile = discard.last;
    if (!human.opened && !canOpenWith(human.rack, tile)) {
      status = 'پێش کردنەوە، پارچەی فڕێدراو تەنها ئەگەر یارمەتیت بدات بۆ کردنەوە وەری بگرە';
      return false;
    }
    human.rack.add(discard.removeLast());
    status = 'پارچەی فڕێدراوت وەرگرت';
    return true;
  }

  bool discardTile(int rackIndex) {
    if (roundOver || currentPlayer != 0 || rackIndex < 0 || rackIndex >= human.rack.length) return false;
    discard.add(human.rack.removeAt(rackIndex));
    status = 'پارچەکەت فڕێدا؛ نۆرەی یاریزانی داهاتووە';
    _advanceBots();
    return true;
  }

  bool openWithSelected(List<int> indexes) {
    if (human.opened || indexes.isEmpty) return false;
    final selected = indexes.toSet().toList()..sort();
    final tiles = selected.map((i) => human.rack[i]).toList();
    final value = tiles.fold<int>(0, (sum, t) => sum + t.points);
    if (!_canPartitionIntoMelds(tiles) || value < 81) {
      status = 'کردنەوە دەبێت لە گرووپ/ڕیزی دروست پێکبێت و لانیکەم ٨١ خاڵ بێت';
      return false;
    }
    for (final i in selected.reversed) {
      human.rack.removeAt(i);
    }
    human.opened = true;
    human.openingPoints = value;
    status = 'کردنەوە سەرکەوتوو بوو: $value خاڵ';
    return true;
  }

  bool _canPartitionIntoMelds(List<Tile> tiles) {
    if (tiles.isEmpty) return true;
    // Try every valid meld containing the first remaining tile, then recurse.
    final first = tiles.first;
    for (var size = 3; size <= min(5, tiles.length); size++) {
      final rest = tiles.skip(1).toList();
      for (final combo in _combinations(rest, size - 1)) {
        final meld = [first, ...combo];
        if (!isValidMeld(meld)) continue;
        final used = combo.toSet();
        final remaining = rest.where((t) => !used.contains(t)).toList();
        if (_canPartitionIntoMelds(remaining)) return true;
      }
    }
    return false;
  }

  List<List<Tile>> _combinations(List<Tile> items, int count) {
    final result = <List<Tile>>[];
    void visit(int start, List<Tile> current) {
      if (current.length == count) { result.add(List.of(current)); return; }
      for (var i = start; i <= items.length - (count - current.length); i++) {
        current.add(items[i]);
        visit(i + 1, current);
        current.removeLast();
      }
    }
    visit(0, []);
    return result;
  }

  bool canOpenWith(List<Tile> rack, Tile extra) {
    // Conservative helper: confirms only if the combined hand reaches the threshold;
    // exact meld selection is validated by isValidMeld when the player opens.
    return rack.fold<int>(extra.points, (sum, tile) => sum + tile.points) >= 81;
  }

  bool isValidMeld(List<Tile> tiles) {
    if (tiles.length < 3 || tiles.length > 5) return false;
    final normal = tiles.where((t) => !t.isAntique).toList();
    if (normal.length != tiles.length) return false;
    final sameNumber = normal.every((t) => t.number == normal.first.number) &&
        normal.map((t) => t.color).toSet().length == normal.length;
    if (sameNumber) return true;
    final sameColor = normal.every((t) => t.color == normal.first.color);
    if (!sameColor) return false;
    final numbers = normal.map((t) => t.number).toList()..sort();
    for (var i = 1; i < numbers.length; i++) {
      if (numbers[i] != numbers[i - 1] + 1) return false;
    }
    return true;
  }

  void _advanceBots() {
    for (var turn = 0; turn < 3; turn++) {
      currentPlayer = (currentPlayer + 1) % 4;
      if (stock.isEmpty) {
        if (discard.length > 1 && reshuffles < 3) {
          final top = discard.removeLast();
          stock = discard..shuffle(_random);
          discard
            ..clear()
            ..add(top);
          reshuffles++;
        } else {
          roundOver = true;
          status = 'دەورەکە کۆتایی هات';
          return;
        }
      }
      final player = players[currentPlayer];
      player.rack.add(stock.removeLast());
      // Simple demonstration bot: discard its highest-value tile.
      player.rack.sort((a, b) => b.points.compareTo(a.points));
      discard.add(player.rack.removeAt(0));
      if (player.rack.isEmpty) {
        roundOver = true;
        status = '${player.name} بردییەوە';
        return;
      }
    }
    currentPlayer = 0;
    status = 'نۆرەی تۆیە؛ پارچە وەربگرە';
  }

  String tileLabel(Tile tile) {
    const colors = {
      TileColor.red: 'سوور',
      TileColor.black: 'ڕەش',
      TileColor.blue: 'شین',
      TileColor.yellow: 'زەرد',
      TileColor.antique: 'ئەنتیک',
    };
    return '${colors[tile.color]} ${tile.number == 0 ? '' : tile.number}';
  }
}
